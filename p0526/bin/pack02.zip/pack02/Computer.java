package pack02;

public class Computer extends Product {
	Computer(){
		super("MACBOOK",150,150/10);
	}

}
