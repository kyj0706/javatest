package pack02;

public class Tv extends Product {
	
	Tv(){
		super("OLEDTV",100,100/10);
//		price = 100;
//		bonusPoint = price/0.1;
	}
}
