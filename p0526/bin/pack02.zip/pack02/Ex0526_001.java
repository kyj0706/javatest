package pack02;

public class Ex0526_001 {

	public static void main(String[] args) {
		CaptionTv ct = new CaptionTv();

	}

}
