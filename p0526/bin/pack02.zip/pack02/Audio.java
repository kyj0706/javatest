package pack02;

public class Audio extends Product {

	Audio(){
		super("SONY",50,50/10);
	}
}
